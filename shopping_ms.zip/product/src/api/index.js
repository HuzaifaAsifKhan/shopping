
module.exports = {
    products: require('./products'),
    appEvents: require('./api-event')
}
